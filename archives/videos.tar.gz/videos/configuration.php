<?php
$global['configurationVersion'] = 3.1;
$global['disableAdvancedConfigurations'] = 0;
$global['videoStorageLimitMinutes'] = 0;
$global['disableTimeFix'] = 0;

$global['logfile'] = '/var/www/AVideo/videos/avideo.log';

if(!empty($_SERVER['SERVER_NAME']) && $_SERVER['SERVER_NAME']!=='localhost' && !filter_var($_SERVER['SERVER_NAME'], FILTER_VALIDATE_IP)) {
    // get the subdirectory, if exists
    $file = str_replace("\\", "/", __FILE__);
    $subDir = str_replace(array($_SERVER["DOCUMENT_ROOT"], 'videos/configuration.php'), array('',''), $file);
    $global['webSiteRootURL'] = "http".(!empty($_SERVER['HTTPS'])?"s":"")."://".$_SERVER['SERVER_NAME'].$subDir;
}else{
    $global['webSiteRootURL'] = 'http://127.0.0.1/';
}
$global['systemRootPath'] = '/var/www/AVideo/';
$global['salt'] = '6251b606621ae';
$global['disableTimeFix'] = 0;
$global['enableDDOSprotection'] = 1;
$global['ddosMaxConnections'] = 40;
$global['ddosSecondTimeout'] = 5;
$global['strictDDOSprotection'] = 0;
$global['noDebug'] = 0;
$global['webSiteRootPath'] = '';
if(empty($global['webSiteRootPath'])){
    preg_match('/https?:\/\/[^\/]+(.*)/i', $global['webSiteRootURL'], $matches);
    if(!empty($matches[1])){
        $global['webSiteRootPath'] = $matches[1];
    }
}
if(empty($global['webSiteRootPath'])){
    die('Please configure your webSiteRootPath');
}
$global['onlyGetResolutionFromFilename'] = 1;

$mysqlHost = 'localhost';
$mysqlPort = '3306';
$mysqlUser = 'AVideo';
$mysqlPass = 'your-password';
$mysqlDatabase = 'AVideo';
$global["mysqli_charset"] = "utf8mb4";

//$global['stopBotsList'] = array('bot','spider','rouwler','Nuclei','MegaIndex','NetSystemsResearch','CensysInspect','slurp','crawler','curl','fetch','loader');
//$global['stopBotsWhiteList'] = array('google','bing','yahoo','yandex','twitter');

/**
 * Do NOT change from here
 */

require_once $global['systemRootPath'].'objects/include_config.php';
