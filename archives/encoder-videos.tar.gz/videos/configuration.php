<?php
$global['configurationVersion'] = 2;
$global['tablesPrefix'] = '';
$global['webSiteRootURL'] = 'http://127.0.0.1/AVideo-Encoder/';
$global['systemRootPath'] = '/var/www/AVideo/AVideo-Encoder/';
$global['webSiteRootPath'] = '';

$global['disableConfigurations'] = false;
$global['disableBulkEncode'] = false;
$global['disableImportVideo'] = false;
$global['disableWebM'] = false;
$global['defaultWebM'] = false;
$global['concurrent'] = 1;
$global['hideUserGroups'] = false;
$global['progressiveUpload'] = false;
$global['killWorkerOnDelete'] = false;

$mysqlHost = 'localhost';
$mysqlUser = 'AVideoEncoder';
$mysqlPass = 'your-password';
$mysqlDatabase = 'AVideoEncoder';

$global['allowed'] = array('mp4', 'avi', 'mov', 'flv', 'mp3', 'wav', 'm4v', 'webm', 'wmv', 'mpg', 'mpeg', 'f4v', 'm4v', 'm4a', 'm2p', 'rm', 'vob', 'mkv', '3gp');
/**
 * Do NOT change from here
 */
if(empty($global['webSiteRootPath'])){
    preg_match('/https?:\/\/[^\/]+(.*)/i', $global['webSiteRootURL'], $matches);
    if(!empty($matches[1])){
        $global['webSiteRootPath'] = $matches[1];
    }
}
if(empty($global['webSiteRootPath'])){
    die('Please configure your webSiteRootPath');
}


require_once $global['systemRootPath'].'objects/include_config.php';
